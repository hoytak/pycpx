Download
========

Installation requires a working C compiler installed on the system.
It looks through the PATH environment variable to try to find the
CPlex and ILog Concert Technology libraries.

The easiest way to install PyCPX is through the python setuptools
``easy_install`` utility by typing::

    easy_install pycpx

You can also install treedict by directly downloading a source tarball
from the python cheeseshop at http://pypi.python.org/pypi/pycpx/. 

For developers, a `git`_ source repository is available on `github`_.
You can clone that repository with the following command::

    git clone git://github.com/hoytak/pycpx.git

Bug reports, questions, or comments are very welcome and can be
submitted at http://github.com/hoytak/pycpx/issues.  Feature additions
and further development are also quite welcome!  Please email me at
hoytak@gmail.com if you have any questions.

.. _ILog Concert Technology: http://www-01.ibm.com/software/integration/optimization/cplex-optimizer/interfaces/#concert_technology
